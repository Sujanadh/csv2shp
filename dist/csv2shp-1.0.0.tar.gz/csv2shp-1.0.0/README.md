# csv2shp

csv2shp is a Python tool for converting CSV data to Shapefile format. It can automatically detect and convert latitude and longitude columns or process WKT geometries in your CSV files.

## Installation

You can install csv2shp package using pip:
pip install csv2shp

### Example



