from .csv2shp import convert_csv_to_shp

def csv2shp(input_csv):
    return convert_csv_to_shp(input_csv)